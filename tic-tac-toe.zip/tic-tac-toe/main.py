data = []
number = 1
for row in range(0, 3):
    data.append([])
    for column in range(0, 3):
        data[row].append(str(number))
        number += 1

game_is_over = False
current_xo = "X"

while not game_is_over:

    position = input(f"Type a position, {current_xo} turn: ")

    not_find = True
    for row in range(0, 3):
        for column in range(0, 3):
            if data[row][column] == position:
                data[row][column] = current_xo
                not_find = False
                break

    if not_find:
        print("Incorrect input, please try again")
        continue

    print(f" {data[0][0]} | {data[0][1]} | {data[0][2]} ")
    print("-----------")
    print(f" {data[1][0]} | {data[1][1]} | {data[1][2]} ")
    print("-----------")
    print(f" {data[2][0]} | {data[2][1]} | {data[2][2]} ")

    counter = 0
    for row in range(0, 2):
        counter = 0
        for column in range(0, 3):
            if data[row][column] == data[row + 1][column]:
                counter += 1
            if counter > 1:
                break

    for row in range(0, 3):
        counter = 0
        for column in range(0, 2):
            if data[row][column] == data[row][column + 1]:
                counter += 1
        if counter > 1:
            break

    for index in range(0, 2):
        if data[index][index] == data[index + 1][index + 1]:
            counter += 1

    if counter > 1:
        game_is_over = True
        print(f"{current_xo} win")

    if current_xo == "X":
        current_xo = "O"
    else:
        current_xo = "X"
