# WriteOrDye
Application inspired by "The Most Dangerous Writing App". Deletes user-written content after 5 seconds of inactivity.

UI built with Tkinter package.

![image](https://github.com/lauraporsch/WriteOrDye/assets/127047376/577af9ae-3222-4fac-ab1c-bf32281c297c)
