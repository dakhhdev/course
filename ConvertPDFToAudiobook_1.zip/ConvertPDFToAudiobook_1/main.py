from pdfminer.high_level import extract_text
from gtts import gTTS
import os

def text_from_pdf(pdf_path):
    try:
        text = extract_text(pdf_path)
        return text
    except Exception as e:
        print(f"Error: {e}")
        return None

def text_to_speech(text, output_file='output.mp3', language='en'):
    try:
        tts = gTTS(text=text, lang=language, tld="com")
        tts.save(output_file)
        return output_file
    except Exception as e:
        print(f"Error: {e}")
        return None

pdf_path = ('sample.pdf')
user_extracted_text = text_from_pdf(pdf_path)
if user_extracted_text:
    user_output_file_audio = text_to_speech(user_extracted_text)
    if user_output_file_audio:
        os.system(f"start {user_output_file_audio}")
        